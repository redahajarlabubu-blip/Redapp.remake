// Sends FCM push notifications. Wire it to Database Webhooks (Database > Webhooks):
//   table messages, event INSERT -> this function     table calls, event INSERT -> this function
// Secrets: supabase secrets set FCM_SERVICE_ACCOUNT='<service account JSON>'   (Firebase console > Project settings > Service accounts)
import { createClient } from "npm:@supabase/supabase-js@2";
import { SignJWT, importPKCS8 } from "npm:jose@5";

const sa = JSON.parse(Deno.env.get("FCM_SERVICE_ACCOUNT") ?? "{}");
const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

async function accessToken(): Promise<string> {
  const key = await importPKCS8(sa.private_key, "RS256");
  const jwt = await new SignJWT({ scope: "https://www.googleapis.com/auth/firebase.messaging" })
    .setProtectedHeader({ alg: "RS256" }).setIssuer(sa.client_email).setSubject(sa.client_email)
    .setAudience("https://oauth2.googleapis.com/token").setIssuedAt().setExpirationTime("55m").sign(key);
  const r = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer", assertion: jwt }),
  });
  return (await r.json()).access_token;
}

Deno.serve(async (req) => {
  const evt = await req.json();
  if (evt.type !== "INSERT") return new Response("ignored");
  const rec = evt.record;
  const isCall = evt.table === "calls";
  const senderId = isCall ? rec.caller_id : rec.sender_id;

  const { data: sender } = await admin.from("profiles").select("display_name").eq("id", senderId).single();
  const { data: mem } = await admin.from("members").select("user_id").eq("conversation_id", rec.conversation_id).neq("user_id", senderId);
  const ids = (mem ?? []).map((m) => m.user_id);
  if (!ids.length) return new Response("no recipients");
  const { data: devs } = await admin.from("devices").select("token, user_id").in("user_id", ids);

  const title = sender?.display_name ?? "RedApp";
  const label: Record<string, string> = { image: "📷 Photo", video: "🎬 Video", file: "📎 File", voice: "🎤 Voice message", sticker: rec.body ?? "" };
  const body = isCall ? (rec.video ? "Incoming video call" : "Incoming call") : (label[rec.kind] ?? rec.body ?? "");
  const bearer = await accessToken();

  await Promise.all((devs ?? []).map((d) =>
    fetch(`https://fcm.googleapis.com/v1/projects/${sa.project_id}/messages:send`, {
      method: "POST", headers: { Authorization: `Bearer ${bearer}`, "Content-Type": "application/json" },
      body: JSON.stringify({ message: { token: d.token, android: { priority: "HIGH" },
        data: { uid: d.user_id, conv: rec.conversation_id, title, body, call: isCall ? "1" : "0" } } }),
    }).then(async (r) => { if (r.status === 404) await admin.from("devices").delete().eq("token", d.token); })
  ));
  return new Response("sent");
});
