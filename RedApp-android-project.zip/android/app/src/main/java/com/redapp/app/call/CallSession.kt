package com.redapp.app.call

import android.content.Context
import android.content.Intent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.redapp.app.BuildConfig
import io.livekit.android.LiveKit
import io.livekit.android.events.RoomEvent
import io.livekit.android.room.Room
import io.livekit.android.room.participant.Participant
import io.livekit.android.room.track.LocalVideoTrack
import io.livekit.android.room.track.Track
import io.livekit.android.room.track.VideoTrack
import io.livekit.android.room.track.screencapture.ScreenCaptureParams
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

/**
 * One live call. 1:1 and group calls are the same thing: everyone joins the LiveKit room named
 * after the call id (WebRTC through an SFU, so group calls scale beyond a peer-to-peer mesh).
 */
class CallSession(
    appContext: Context,
    val callId: String,
    val video: Boolean,
    val title: String,
    val isGroup: Boolean,
    val iAmCaller: Boolean,
) {
    private val ctx = appContext.applicationContext
    val room: Room = LiveKit.create(ctx)

    /** Bumped on every room event so Compose re-reads participants and tracks. */
    var tick by mutableIntStateOf(0); private set
    var connected by mutableStateOf(false); private set
    var micOn by mutableStateOf(true); private set
    var camOn by mutableStateOf(video); private set
    var sharing by mutableStateOf(false); private set
    var failed by mutableStateOf<String?>(null); private set

    suspend fun connect(scope: CoroutineScope, token: String, onRemoteLeft: () -> Unit) {
        scope.launch {
            room.events.events.collect { e ->
                tick++
                if (e is RoomEvent.ParticipantDisconnected && !isGroup && room.remoteParticipants.isEmpty()) onRemoteLeft()
                if (e is RoomEvent.Disconnected) connected = false
            }
        }
        room.connect(BuildConfig.LIVEKIT_URL, token)
        connected = true
        room.localParticipant.setMicrophoneEnabled(true)
        if (video) room.localParticipant.setCameraEnabled(true)
        tick++
    }

    suspend fun toggleMic() { micOn = !micOn; room.localParticipant.setMicrophoneEnabled(micOn) }
    suspend fun toggleCam() { camOn = !camOn; room.localParticipant.setCameraEnabled(camOn); tick++ }

    /** [permissionData] is the result Intent from MediaProjectionManager.createScreenCaptureIntent(). */
    suspend fun startShare(permissionData: Intent) {
        ctx.startForegroundService(Intent(ctx, ScreenShareService::class.java)) // must run before capture starts (Android 14)
        room.localParticipant.setScreenShareEnabled(true, ScreenCaptureParams(permissionData))
        sharing = true; tick++
    }

    suspend fun stopShare() {
        runCatching { room.localParticipant.setScreenShareEnabled(false) }
        ctx.stopService(Intent(ctx, ScreenShareService::class.java))
        sharing = false; tick++
    }

    fun participants(): List<Participant> =
        buildList { add(room.localParticipant); addAll(room.remoteParticipants.values) }

    /** Screen share wins over camera when someone is presenting. */
    fun videoOf(p: Participant): VideoTrack? =
        (p.getTrackPublication(Track.Source.SCREEN_SHARE)?.track as? VideoTrack)
            ?: (p.getTrackPublication(Track.Source.CAMERA)?.track as? VideoTrack)

    fun disconnect() {
        runCatching { ctx.stopService(Intent(ctx, ScreenShareService::class.java)) }
        runCatching { room.disconnect() }
        runCatching { room.release() }
    }
}
