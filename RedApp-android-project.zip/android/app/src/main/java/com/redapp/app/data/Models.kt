package com.redapp.app.data

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import java.time.Instant
import java.time.OffsetDateTime

@Serializable
data class Profile(
    val id: String,
    val username: String,
    @SerialName("display_name") val displayName: String,
    @SerialName("last_seen") val lastSeen: String? = null,
)

@Serializable
data class ConvRow(
    val id: String,
    @SerialName("is_group") val isGroup: Boolean,
    val title: String? = null,
    @SerialName("last_body") val lastBody: String? = null,
    @SerialName("last_kind") val lastKind: String? = null,
    @SerialName("last_at") val lastAt: String? = null,
    val unread: Long = 0,
    @SerialName("peer_id") val peerId: String? = null,
    @SerialName("peer_last_seen") val peerLastSeen: String? = null,
    @SerialName("member_count") val memberCount: Long = 2,
)

@Serializable
data class Msg(
    val id: String,
    @SerialName("conversation_id") val conversationId: String,
    @SerialName("sender_id") val senderId: String,
    val kind: String,
    val body: String? = null,
    @SerialName("media_path") val mediaPath: String? = null,
    @SerialName("media_name") val mediaName: String? = null,
    @SerialName("created_at") val createdAt: String,
)

@Serializable
data class MsgInsert(
    @SerialName("conversation_id") val conversationId: String,
    val kind: String,
    val body: String? = null,
    @SerialName("media_path") val mediaPath: String? = null,
    @SerialName("media_name") val mediaName: String? = null,
)

@Serializable
data class Receipt(
    @SerialName("message_id") val messageId: String,
    @SerialName("user_id") val userId: String,
    @SerialName("delivered_at") val deliveredAt: String? = null,
    @SerialName("read_at") val readAt: String? = null,
)

@Serializable
data class CallRow(
    val id: String,
    @SerialName("conversation_id") val conversationId: String,
    @SerialName("caller_id") val callerId: String,
    val video: Boolean,
    @SerialName("created_at") val createdAt: String,
    @SerialName("ended_at") val endedAt: String? = null,
)

@Serializable
data class CallInsert(@SerialName("conversation_id") val conversationId: String, val video: Boolean)

@Serializable
data class Account(val userId: String, val username: String, val displayName: String, val session: String)

fun String?.toInstantOrNull(): Instant? =
    runCatching { OffsetDateTime.parse(this!!).toInstant() }.getOrNull()

fun ageSeconds(ts: String?): Long = ts.toInstantOrNull()?.let { Instant.now().epochSecond - it.epochSecond } ?: Long.MAX_VALUE

/** Considered online if the heartbeat (every 30 s) arrived within the last 75 s. */
fun isOnline(lastSeen: String?): Boolean = ageSeconds(lastSeen) < 75
