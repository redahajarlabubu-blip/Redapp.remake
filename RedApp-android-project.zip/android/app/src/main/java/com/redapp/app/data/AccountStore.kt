package com.redapp.app.data

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * All accounts on this device. Session tokens are encrypted at rest with a hardware-backed
 * Android Keystore key. Settings are namespaced per account id, so accounts never share state.
 */
class AccountStore(ctx: Context) {
    private val json = Json { ignoreUnknownKeys = true }
    private val prefs = EncryptedSharedPreferences.create(
        ctx, "redapp_secure",
        MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
    )

    fun all(): List<Account> =
        prefs.getString("accounts", null)?.let { runCatching { json.decodeFromString<List<Account>>(it) }.getOrNull() }.orEmpty()

    fun save(a: Account) {
        val list = all().filterNot { it.userId == a.userId } + a
        prefs.edit().putString("accounts", json.encodeToString(list)).apply()
    }

    fun remove(userId: String) {
        prefs.edit().putString("accounts", json.encodeToString(all().filterNot { it.userId == userId })).apply()
        prefs.edit().remove("active").apply()
        prefs.all.keys.filter { it.startsWith("$userId:") }.forEach { prefs.edit().remove(it).apply() }
    }

    var activeId: String?
        get() = prefs.getString("active", null)
        set(v) { prefs.edit().putString("active", v).apply() }

    fun flag(userId: String, key: String, default: Boolean) = prefs.getBoolean("$userId:$key", default)
    fun setFlag(userId: String, key: String, v: Boolean) = prefs.edit().putBoolean("$userId:$key", v).apply()
}
