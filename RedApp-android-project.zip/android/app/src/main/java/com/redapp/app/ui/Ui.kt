package com.redapp.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.redapp.app.R
import com.redapp.app.data.ageSeconds
import com.redapp.app.data.isOnline
import com.redapp.app.data.toInstantOrNull
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/** Design tokens copied from the existing RedApp web app (app.html / index.html). */
object C {
    val Paper = Color(0xFFEDF0F5); val Ink = Color(0xFF14214F); val Muted = Color(0xFF667089)
    val Line = Color(0xFFD9DEE8); val Soft = Color(0xFFF6F8FB); val Accent = Color(0xFF0FA3B1)
    val Live = Color(0xFF22A06B); val Bad = Color(0xFFD64545); val Red = Color(0xFFF0283C)
    val Active = Color(0xFFF1F4FA); val Banner = Color(0xFFFFF4D6); val BannerText = Color(0xFF6B4A00)
    val Navy = Color(0xFF060B1E); val Navy2 = Color(0xFF0A1230)
    val BrandGrad = Brush.linearGradient(listOf(Color(0xFF0A3FBF), Color(0xFF0A7BE0), Color(0xFF00D4FF)))
}

@Composable
fun RedAppTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = lightColorScheme(
        primary = C.Ink, onPrimary = Color.White, secondary = C.Accent,
        background = Color.White, surface = Color.White, onSurface = C.Ink, error = C.Bad,
    ),
    content = content,
)

/** "Red" in red bold, "App" in ink, like the web wordmark. */
@Composable
fun BrandWord(size: TextUnit = 30.sp, onDark: Boolean = false) = androidx.compose.material3.Text(
    buildAnnotatedString {
        withStyle(SpanStyle(color = C.Red, fontWeight = FontWeight.ExtraBold)) { append("Red") }
        withStyle(SpanStyle(color = if (onDark) Color.White else C.Ink, fontWeight = FontWeight.ExtraBold)) { append("App") }
    },
    fontSize = size, letterSpacing = (-0.03).em(size),
)
private fun Double.em(size: TextUnit) = (this * size.value).sp

@Composable
fun Avatar(name: String, size: Dp = 46.dp, online: Boolean = false) {
    Box {
        Box(
            Modifier.size(size).clip(CircleShape).background(C.BrandGrad),
            contentAlignment = Alignment.Center,
        ) {
            Text(name.trim().take(1).uppercase().ifEmpty { "?" }, color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.42f).sp)
        }
        if (online) Box(Modifier.size(size / 4).align(Alignment.BottomEnd).clip(CircleShape).background(Color.White).padding(1.5.dp).clip(CircleShape).background(C.Live))
    }
}

@Composable
fun presenceText(lastSeen: String?): String {
    if (isOnline(lastSeen)) return stringResource(R.string.online)
    val s = ageSeconds(lastSeen)
    if (s == Long.MAX_VALUE) return stringResource(R.string.offline)
    val rel = when {
        s < 60 -> stringResource(R.string.just_now)
        s < 3600 -> stringResource(R.string.min_ago, s / 60)
        s < 86400 -> stringResource(R.string.hours_ago, s / 3600)
        else -> stringResource(R.string.yesterday)
    }
    return stringResource(R.string.last_seen, rel)
}

private val hm = DateTimeFormatter.ofPattern("HH:mm").withZone(ZoneId.systemDefault())
private val dm = DateTimeFormatter.ofPattern("d MMM").withZone(ZoneId.systemDefault())
fun clock(ts: String?): String = ts.toInstantOrNull()?.let {
    if (ageSeconds(ts) < 86400) hm.format(it) else dm.format(it)
} ?: ""

@Composable
fun Banner(text: String, modifier: Modifier = Modifier) =
    Text(text, Modifier.fillMaxWidth().background(C.Banner).padding(horizontal = 16.dp, vertical = 8.dp).then(modifier), color = C.BannerText, fontSize = 14.sp)

@Composable
fun Text(text: String, modifier: Modifier = Modifier, color: Color = C.Ink, fontSize: TextUnit = 16.sp,
         fontWeight: FontWeight? = null, maxLines: Int = Int.MAX_VALUE) =
    androidx.compose.material3.Text(text, modifier, color = color, fontSize = fontSize, fontWeight = fontWeight,
        maxLines = maxLines, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
