package com.redapp.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.redapp.app.R
import com.redapp.app.data.ConvRow
import com.redapp.app.data.Profile
import androidx.compose.ui.graphics.Color

private val field = @Composable { OutlinedTextFieldDefaults.colors(focusedBorderColor = C.Ink, unfocusedBorderColor = C.Line, cursorColor = C.Ink) }

// ---------------------------------------------------------------- sign in / create account
@Composable
fun AuthScreen(vm: AppVM) {
    var signUp by remember { mutableStateOf(true) }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    val canSubmit = user.trim().length in 3..20 && pass.length >= 6 && !vm.busy && vm.be.configured
    Column(Modifier.fillMaxSize().systemBarsPadding().imePadding().padding(24.dp), verticalArrangement = Arrangement.Center) {
        if (vm.addingAccount) TextButton(onClick = { vm.addingAccount = false; vm.screen = Screen.Settings }) { Text(stringResource(R.string.cancel), color = C.Muted) }
        BrandWord(40.sp)
        Spacer(Modifier.height(4.dp))
        Text(stringResource(R.string.tagline), color = C.Muted)
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(user, { user = it.filter { c -> c.isLetterOrDigit() || c == '_' }.take(20) }, Modifier.fillMaxWidth(),
            label = { androidx.compose.material3.Text(stringResource(R.string.username)) }, singleLine = true,
            supportingText = { androidx.compose.material3.Text(stringResource(R.string.username_hint)) }, colors = field())
        if (signUp) {
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(name, { name = it.take(40) }, Modifier.fillMaxWidth(),
                label = { androidx.compose.material3.Text(stringResource(R.string.display_name)) }, singleLine = true, colors = field())
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(pass, { pass = it }, Modifier.fillMaxWidth(),
            label = { androidx.compose.material3.Text(stringResource(R.string.password)) }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), colors = field())
        val msg = if (!vm.be.configured) stringResource(R.string.config_missing) else vm.error?.let { friendly(it) }
        if (msg != null) { Spacer(Modifier.height(12.dp)); Text(msg, color = C.Bad, fontSize = 14.sp) }
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { vm.submitAuth(user, pass, name, signUp) }, enabled = canSubmit, modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = C.Ink),
        ) { Text(stringResource(if (signUp) R.string.create_account else R.string.sign_in), color = Color.White, fontWeight = FontWeight.Bold) }
        TextButton(onClick = { signUp = !signUp; vm.error = null }, Modifier.align(Alignment.CenterHorizontally)) {
            Text(stringResource(if (signUp) R.string.have_account else R.string.need_account), color = C.Accent)
        }
    }
}

@Composable
private fun friendly(raw: String): String = when {
    raw.contains("Invalid login", true) || raw.contains("invalid_credentials", true) -> stringResource(R.string.bad_login)
    raw.contains("already", true) || raw.contains("Database error", true) || raw.contains("duplicate", true) -> stringResource(R.string.name_taken)
    else -> raw.ifBlank { stringResource(R.string.error_generic) }
}

// ---------------------------------------------------------------- chat list
@Composable
fun ListScreen(vm: AppVM) {
    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 18.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            BrandWord(30.sp)
            // "me" pill: opens accounts + settings
            Row(
                Modifier.widthIn(max = 200.dp).clip(RoundedCornerShape(999.dp)).background(C.Soft).clickable { vm.screen = Screen.Settings }
                    .padding(start = 6.dp, end = 12.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Avatar(vm.me?.displayName ?: "?", 28.dp)
                Text(vm.me?.displayName ?: "", fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1)
            }
        }
        vm.error?.let { Banner(it) }
        if (vm.convs.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth().padding(28.dp), contentAlignment = Alignment.TopCenter) {
                Text(stringResource(R.string.no_chats), color = C.Muted, fontSize = 15.sp)
            }
        } else LazyColumn(Modifier.weight(1f)) {
            items(vm.convs, key = { it.id }) { c -> ConvRowView(c, vm.openConv?.id == c.id) { vm.openChat(c) } }
        }
        HorizontalDivider(color = C.Line)
        Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(16.dp, 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ModeCard(stringResource(R.string.new_chat), Modifier.weight(1f)) { vm.results = emptyList(); vm.screen = Screen.NewChat }
            ModeCard(stringResource(R.string.new_group), Modifier.weight(1f)) { vm.results = emptyList(); vm.screen = Screen.NewGroup }
        }
    }
}

@Composable
private fun ModeCard(label: String, modifier: Modifier, onClick: () -> Unit) {
    Surface(modifier.clickable(onClick = onClick), shape = RoundedCornerShape(14.dp), border = BorderStroke(1.dp, C.Line), color = Color.White) {
        Text(label, Modifier.padding(14.dp), fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ConvRowView(c: ConvRow, active: Boolean, onClick: () -> Unit) {
    val preview = when (c.lastKind) {
        "image" -> "📷 " + stringResource(R.string.photo); "video" -> "🎬 " + stringResource(R.string.video)
        "file" -> "📎 " + stringResource(R.string.file); "voice" -> "🎤 " + stringResource(R.string.voice)
        else -> c.lastBody.orEmpty()
    }
    Column(Modifier.background(if (active) C.Active else Color.White).clickable(onClick = onClick)) {
        Row(Modifier.fillMaxWidth().padding(16.dp, 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Avatar(c.title ?: "?", 46.dp, online = !c.isGroup && com.redapp.app.data.isOnline(c.peerLastSeen))
            Column(Modifier.weight(1f)) {
                Text(c.title ?: stringResource(R.string.group), fontWeight = FontWeight.Bold, maxLines = 1)
                Text(preview, color = C.Muted, fontSize = 14.sp, maxLines = 1)
            }
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(clock(c.lastAt), color = C.Muted, fontSize = 12.sp)
                if (c.unread > 0) Text(c.unread.toString(), color = Color.White, fontSize = 12.sp,
                    modifier = Modifier.clip(CircleShape).background(C.Ink).padding(horizontal = 7.dp, vertical = 1.dp))
            }
        }
        HorizontalDivider(color = C.Line)
    }
}

// ---------------------------------------------------------------- new chat / new group
@Composable
fun NewChatScreen(vm: AppVM, group: Boolean) {
    var q by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    val picked = remember { mutableStateListOf<Profile>() }
    Column(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ vm.screen = Screen.List }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back), tint = C.Ink) }
            Text(stringResource(if (group) R.string.new_group else R.string.new_chat), fontWeight = FontWeight.ExtraBold, fontSize = 22.sp, modifier = Modifier.weight(1f))
            if (group) TextButton(onClick = { vm.createGroup(title, picked.toList()) }, enabled = picked.isNotEmpty()) {
                Text(stringResource(R.string.start_group), color = if (picked.isNotEmpty()) C.Accent else C.Muted, fontWeight = FontWeight.Bold)
            }
        }
        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (group) OutlinedTextField(title, { title = it.take(60) }, Modifier.fillMaxWidth(), singleLine = true,
                label = { androidx.compose.material3.Text(stringResource(R.string.group_name)) }, colors = field())
            OutlinedTextField(q, { q = it; vm.search(it) }, Modifier.fillMaxWidth(), singleLine = true,
                label = { androidx.compose.material3.Text(stringResource(R.string.search_users)) }, colors = field())
            if (group && picked.isNotEmpty()) Text(stringResource(R.string.selected, picked.size), color = C.Muted, fontSize = 13.sp)
        }
        vm.error?.let { Banner(it) }
        if (q.trim().length >= 2 && vm.results.isEmpty()) Text(stringResource(R.string.no_results), Modifier.padding(24.dp), color = C.Muted)
        else if (q.isBlank()) Text(stringResource(R.string.tap_chat), Modifier.padding(24.dp), color = C.Muted)
        LazyColumn {
            items(vm.results, key = { it.id }) { p ->
                val on = picked.any { it.id == p.id }
                Row(
                    Modifier.fillMaxWidth().clickable {
                        if (!group) vm.startDirect(p) else if (on) picked.removeAll { it.id == p.id } else picked.add(p)
                    }.padding(16.dp, 10.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Avatar(p.displayName, 46.dp, com.redapp.app.data.isOnline(p.lastSeen))
                    Column(Modifier.weight(1f)) {
                        Text(p.displayName, fontWeight = FontWeight.Bold, maxLines = 1)
                        Text("@${p.username}", color = C.Muted, fontSize = 14.sp, maxLines = 1)
                    }
                    if (on) Icon(Icons.Filled.Check, null, tint = C.Accent)
                }
                HorizontalDivider(color = C.Line)
            }
        }
    }
}

// ---------------------------------------------------------------- settings + accounts
@Composable
fun SettingsScreen(vm: AppVM) {
    var name by remember(vm.me?.id) { mutableStateOf(vm.me?.displayName.orEmpty()) }
    var notif by remember(vm.me?.id) { mutableStateOf(vm.notificationsOn()) }
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(bottom = 8.dp)) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ vm.screen = Screen.List }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back), tint = C.Ink) }
            Text(stringResource(R.string.settings), fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
        }
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(name, { name = it.take(40) }, Modifier.weight(1f), singleLine = true,
                        label = { androidx.compose.material3.Text(stringResource(R.string.display_name)) }, colors = field())
                    Button({ vm.rename(name) }, enabled = name.isNotBlank() && name != vm.me?.displayName,
                        colors = ButtonDefaults.buttonColors(containerColor = C.Ink)) { Text(stringResource(R.string.save), color = Color.White) }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(stringResource(R.string.notifications), Modifier.weight(1f))
                    Switch(notif, { notif = it; vm.setNotifications(it) }, colors = SwitchDefaults.colors(checkedTrackColor = C.Ink))
                }
            }
            item { HorizontalDivider(color = C.Line); Text(stringResource(R.string.accounts), fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, modifier = Modifier.padding(top = 8.dp)) }
            items(vm.accounts, key = { it.userId }) { a ->
                val active = a.userId == vm.me?.id
                Surface(shape = RoundedCornerShape(14.dp), border = BorderStroke(1.dp, if (active) C.Ink else C.Line), color = if (active) C.Active else Color.White) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Avatar(a.displayName, 42.dp)
                        Column(Modifier.weight(1f)) {
                            Text(a.displayName, fontWeight = FontWeight.Bold, maxLines = 1)
                            Text(if (active) "@${a.username} · " + stringResource(R.string.active_account) else "@${a.username}", color = C.Muted, fontSize = 13.sp, maxLines = 1)
                        }
                        if (!active) TextButton({ vm.switchTo(a) }) { Text(stringResource(R.string.switch_account), color = C.Accent, fontWeight = FontWeight.Bold) }
                        TextButton({ vm.removeAccount(a) }) { Text(stringResource(R.string.remove_account), color = C.Bad) }
                    }
                }
            }
            item {
                OutlinedButton({ vm.beginAddAccount() }, Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(14.dp), border = BorderStroke(1.dp, C.Ink)) {
                    Text(stringResource(R.string.add_account), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
