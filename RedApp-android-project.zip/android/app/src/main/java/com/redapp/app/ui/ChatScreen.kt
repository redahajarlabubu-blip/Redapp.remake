package com.redapp.app.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import com.redapp.app.R
import com.redapp.app.data.ConvRow
import com.redapp.app.data.Msg
import java.io.File

private val STICKERS = listOf("😀", "😂", "😍", "🥳", "😎", "🤔", "😭", "👍", "👏", "🙏", "🔥", "❤️", "🎉", "💯", "🚀", "😴")

/** Asks for mic (+camera for video) and then runs [go]. */
@Composable
fun withCallPermissions(video: Boolean, go: () -> Unit): () -> Unit {
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[Manifest.permission.RECORD_AUDIO] == true) go()
    }
    return {
        val p = buildList { add(Manifest.permission.RECORD_AUDIO); if (video) add(Manifest.permission.CAMERA)
            if (Build.VERSION.SDK_INT >= 31) add(Manifest.permission.BLUETOOTH_CONNECT) }
        launcher.launch(p.toTypedArray())
    }
}

@Composable
fun ChatScreen(vm: AppVM) {
    val conv = vm.openConv ?: return
    val ctx = LocalContext.current
    var text by remember { mutableStateOf("") }
    var stickers by remember { mutableStateOf(false) }
    val recorder = remember { VoiceRecorder(ctx) }
    var recording by remember { mutableStateOf(false) }
    val list = rememberLazyListState()

    LaunchedEffect(vm.msgs.size) { if (vm.msgs.isNotEmpty()) list.animateScrollToItem(vm.msgs.lastIndex) }
    DisposableEffect(Unit) { onDispose { recorder.cancel() } }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> uri?.let(vm::sendUri) }
    val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok && recorder.start()) recording = true }
    val voiceCall = withCallPermissions(false) { vm.startCall(false) }
    val videoCall = withCallPermissions(true) { vm.startCall(true) }

    Column(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
        // header
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(vm::closeChat) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back), tint = C.Ink) }
            Avatar(conv.title ?: "?", 40.dp, !conv.isGroup && com.redapp.app.data.isOnline(conv.peerLastSeen))
            Column(Modifier.weight(1f).padding(start = 10.dp)) {
                Text(conv.title ?: stringResource(R.string.group), fontWeight = FontWeight.Bold, maxLines = 1)
                Text(if (conv.isGroup) stringResource(R.string.members, conv.memberCount) else presenceText(conv.peerLastSeen),
                    color = if (!conv.isGroup && com.redapp.app.data.isOnline(conv.peerLastSeen)) C.Live else C.Muted, fontSize = 13.sp, maxLines = 1)
            }
            IconButton(voiceCall) { Icon(Icons.Filled.Call, stringResource(R.string.voice_call), tint = C.Ink) }
            IconButton(videoCall) { Icon(Icons.Filled.Videocam, stringResource(R.string.video_call), tint = C.Ink) }
        }
        HorizontalDivider(color = C.Line)
        vm.error?.let { Banner(it) }

        LazyColumn(Modifier.weight(1f).fillMaxWidth().background(C.Paper), state = list,
            contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(vm.msgs, key = { it.id }) { m -> Bubble(vm, conv, m) }
        }

        if (stickers) FlowStickers { vm.sendText(it, "sticker"); stickers = false }
        HorizontalDivider(color = C.Line)
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            if (recording) {
                Text(stringResource(R.string.recording), Modifier.weight(1f).padding(12.dp), color = C.Bad)
                IconButton({ recorder.cancel(); recording = false }) { Icon(Icons.Filled.Close, stringResource(R.string.cancel), tint = C.Muted) }
                IconButton({ recorder.stop()?.let(vm::sendVoice); recording = false }) { Icon(Icons.AutoMirrored.Filled.Send, stringResource(R.string.voice_msg), tint = C.Ink) }
            } else {
                IconButton({ pick.launch("*/*") }) { Icon(Icons.Filled.AttachFile, stringResource(R.string.attach), tint = C.Muted) }
                IconButton({ stickers = !stickers }) { Icon(Icons.Filled.EmojiEmotions, stringResource(R.string.sticker), tint = C.Muted) }
                OutlinedTextField(text, { text = it }, Modifier.weight(1f), maxLines = 5,
                    placeholder = { androidx.compose.material3.Text(stringResource(R.string.message)) }, shape = RoundedCornerShape(22.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = C.Ink, unfocusedBorderColor = C.Line, cursorColor = C.Ink))
                if (text.isBlank()) IconButton({ micPerm.launch(Manifest.permission.RECORD_AUDIO) }) { Icon(Icons.Filled.Mic, stringResource(R.string.voice_msg), tint = C.Ink) }
                else IconButton({ vm.sendText(text); text = "" }) { Icon(Icons.AutoMirrored.Filled.Send, stringResource(R.string.send), tint = C.Ink) }
            }
        }
    }
}

@Composable
private fun FlowStickers(onPick: (String) -> Unit) {
    Column(Modifier.fillMaxWidth().background(Color.White).padding(8.dp)) {
        STICKERS.chunked(8).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                row.forEach { e -> Text(e, Modifier.clickable { onPick(e) }.padding(6.dp), fontSize = 28.sp) }
            }
        }
    }
}

@Composable
private fun Bubble(vm: AppVM, conv: ConvRow, m: Msg) {
    val mine = m.senderId == vm.be.meId
    val ctx = LocalContext.current
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        Column(
            Modifier.widthIn(max = 290.dp).clip(RoundedCornerShape(16.dp)).background(if (mine) C.Ink else Color.White).padding(10.dp, 7.dp),
        ) {
            if (conv.isGroup && !mine) Text(vm.names[m.senderId] ?: "…", color = C.Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            val fg = if (mine) Color.White else C.Ink
            when (m.kind) {
                "sticker" -> Text(m.body.orEmpty(), fontSize = 44.sp)
                "image" -> m.mediaPath?.let { p ->
                    val url by produceState<String?>(null, p) { value = runCatching { vm.be.url(p) }.getOrNull() }
                    AsyncImage(url, m.mediaName, Modifier.sizeIn(maxWidth = 260.dp, maxHeight = 320.dp).clip(RoundedCornerShape(10.dp)), contentScale = ContentScale.Fit)
                }
                "voice" -> m.mediaPath?.let { VoiceBubble(vm, it, fg) }
                "video", "file" -> m.mediaPath?.let { p ->
                    Row(Modifier.clickable { /* open via the system viewer with a fresh signed URL */
                        vm.openExternal(ctx, p)
                    }, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(if (m.kind == "video") Icons.Filled.PlayCircle else Icons.Filled.InsertDriveFile, null, tint = fg)
                        Text(m.mediaName ?: stringResource(R.string.file), color = fg, maxLines = 2)
                    }
                }
                else -> Text(m.body.orEmpty(), color = fg)
            }
            Row(Modifier.align(Alignment.End), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(clock(m.createdAt), color = if (mine) Color(0xFFB8C2E0) else C.Muted, fontSize = 11.sp)
                if (mine) Ticks(vm, conv, m)
            }
        }
    }
}

/** ✓ sent · ✓✓ delivered · ✓✓ (teal) read by everyone. */
@Composable
private fun Ticks(vm: AppVM, conv: ConvRow, m: Msg) {
    val rs = vm.receipts.filter { it.messageId == m.id }
    val others = (conv.memberCount - 1).coerceAtLeast(1)
    val read = rs.count { it.readAt != null }
    val delivered = rs.count { it.deliveredAt != null }
    when {
        read >= others -> Text("✓✓", color = Color(0xFF00D4FF), fontSize = 11.sp, fontWeight = FontWeight.Bold)
        delivered >= 1 -> Text("✓✓", color = Color(0xFFB8C2E0), fontSize = 11.sp)
        else -> Text("✓", color = Color(0xFFB8C2E0), fontSize = 11.sp)
    }
}

@Composable
private fun VoiceBubble(vm: AppVM, path: String, fg: Color) {
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    var playing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    DisposableEffect(Unit) { onDispose { player?.release() } }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        IconButton({
            if (playing) { player?.pause(); playing = false }
            else if (player != null) { player?.start(); playing = true }
            else scope.launch {
              runCatching {
                val url = vm.be.url(path)
                player = MediaPlayer().apply {
                    setDataSource(url); setOnPreparedListener { it.start(); playing = true }
                    setOnCompletionListener { playing = false; it.seekTo(0) }; prepareAsync()
                }
              }
            }
        }) { Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, stringResource(R.string.voice), tint = fg) }
        Text(stringResource(R.string.voice), color = fg)
    }
}

class VoiceRecorder(private val ctx: Context) {
    private var rec: MediaRecorder? = null
    private var file: File? = null

    fun start(): Boolean = runCatching {
        val f = File(ctx.cacheDir, "voice_${System.currentTimeMillis()}.m4a")
        val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else @Suppress("DEPRECATION") MediaRecorder()
        r.setAudioSource(MediaRecorder.AudioSource.MIC); r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
        r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC); r.setAudioEncodingBitRate(64_000); r.setAudioSamplingRate(44_100)
        r.setOutputFile(f.absolutePath); r.prepare(); r.start()
        rec = r; file = f; true
    }.getOrDefault(false)

    fun stop(): File? {
        val f = file
        runCatching { rec?.stop() }.onFailure { f?.delete(); rec = null; file = null; return null }
        runCatching { rec?.release() }; rec = null; file = null
        return f
    }

    fun cancel() { runCatching { rec?.stop() }; runCatching { rec?.release() }; rec = null; file?.delete(); file = null }
}
