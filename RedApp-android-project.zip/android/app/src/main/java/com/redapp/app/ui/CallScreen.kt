package com.redapp.app.ui

import android.content.Context
import android.media.projection.MediaProjectionManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.redapp.app.R
import com.redapp.app.call.CallSession
import io.livekit.android.renderer.TextureViewRenderer
import io.livekit.android.room.Room
import io.livekit.android.room.track.VideoTrack
import kotlinx.coroutines.launch

@Composable
fun CallScreen(vm: AppVM) {
    val s = vm.call ?: return
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val shareLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == android.app.Activity.RESULT_OK && data != null) scope.launch { runCatching { s.startShare(data) } }
    }
    // read tick so Compose recomposes on every room event
    val parts = remember(s.tick) { s.participants() }

    Column(Modifier.fillMaxSize().background(C.Navy).systemBarsPadding()) {
        Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(s.title.ifBlank { stringResource(R.string.group) }, color = Color.White, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, fontSize = 20.sp)
            Text(if (s.connected) stringResource(R.string.members, parts.size) else stringResource(R.string.connecting), color = Color(0xFF9AA7CC), fontSize = 14.sp)
        }
        val cols = when { parts.size <= 1 -> 1; parts.size <= 4 -> 2; else -> 3 }
        LazyVerticalGrid(GridCells.Fixed(cols), Modifier.weight(1f).padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(parts, key = { it.identity?.value ?: "me" }) { p ->
                val name = if (p === s.room.localParticipant) stringResource(R.string.you) else p.name?.takeIf { it.isNotBlank() } ?: "…"
                VideoTile(s.room, s.videoOf(p), name, Modifier.fillMaxWidth().aspectRatio(if (cols == 1) 0.75f else 0.8f))
            }
        }
        Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(16.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            Round(if (s.micOn) Icons.Filled.Mic else Icons.Filled.MicOff, stringResource(R.string.mic), !s.micOn) { scope.launch { runCatching { s.toggleMic() } } }
            Round(if (s.camOn) Icons.Filled.Videocam else Icons.Filled.VideocamOff, stringResource(R.string.camera), !s.camOn) {
                scope.launch { runCatching { s.toggleCam() } }
            }
            Round(if (s.sharing) Icons.Filled.StopScreenShare else Icons.Filled.ScreenShare,
                stringResource(if (s.sharing) R.string.stop_share else R.string.share_screen), s.sharing) {
                if (s.sharing) scope.launch { s.stopShare() }
                else shareLauncher.launch((ctx.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).createScreenCaptureIntent())
            }
            Box(Modifier.size(60.dp).clip(CircleShape).background(C.Red), contentAlignment = Alignment.Center) {
                IconButton(vm::endCall) { Icon(Icons.Filled.CallEnd, stringResource(R.string.hang_up), tint = Color.White) }
            }
        }
    }
}

@Composable
private fun Round(icon: androidx.compose.ui.graphics.vector.ImageVector, desc: String, highlighted: Boolean, onClick: () -> Unit) {
    Box(Modifier.size(52.dp).clip(CircleShape).background(if (highlighted) Color.White else Color(0x26FFFFFF)), contentAlignment = Alignment.Center) {
        IconButton(onClick) { Icon(icon, desc, tint = if (highlighted) C.Navy else Color.White) }
    }
}

/** Renders a LiveKit video track (camera or shared screen), or an avatar when there is no video. */
@Composable
private fun VideoTile(room: Room, track: VideoTrack?, label: String, modifier: Modifier) {
    Box(modifier.clip(RoundedCornerShape(16.dp)).background(C.Navy2)) {
        if (track != null) {
            var renderer by remember { mutableStateOf<TextureViewRenderer?>(null) }
            AndroidView(factory = { c -> TextureViewRenderer(c).also { room.initVideoRenderer(it); renderer = it } }, modifier = Modifier.fillMaxSize())
            DisposableEffect(track, renderer) {
                val r = renderer
                if (r != null) track.addRenderer(r)
                onDispose { if (r != null) track.removeRenderer(r) }
            }
        } else Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Avatar(label, 72.dp) }
        Text(label, Modifier.align(Alignment.BottomStart).padding(10.dp).clip(RoundedCornerShape(8.dp)).background(Color(0x99000000)).padding(horizontal = 8.dp, vertical = 2.dp),
            color = Color.White, fontSize = 13.sp, maxLines = 1)
    }
}
