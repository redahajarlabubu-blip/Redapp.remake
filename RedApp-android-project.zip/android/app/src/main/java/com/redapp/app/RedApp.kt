package com.redapp.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import com.redapp.app.data.Backend

class RedApp : Application() {
    lateinit var backend: Backend
        private set

    override fun onCreate() {
        super.onCreate()
        backend = Backend(this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("messages", "Messages", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel("call", "Calls", NotificationManager.IMPORTANCE_HIGH))
    }
}
