package com.redapp.app.ui

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.FirebaseApp
import com.google.firebase.messaging.FirebaseMessaging
import com.redapp.app.RedApp
import com.redapp.app.call.CallSession
import com.redapp.app.data.*
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.auth.status.SessionStatus
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.io.File

enum class Screen { Boot, Auth, List, Chat, NewChat, NewGroup, Settings, Call }

class AppVM(app: Application) : AndroidViewModel(app) {
    val be: Backend = (app as RedApp).backend

    var screen by mutableStateOf(Screen.Boot)
    var accounts by mutableStateOf(be.store.all())
    var me by mutableStateOf<Profile?>(null)
    var convs by mutableStateOf<List<ConvRow>>(emptyList())
    var openConv by mutableStateOf<ConvRow?>(null)
    var msgs by mutableStateOf<List<Msg>>(emptyList())
    var receipts by mutableStateOf<List<Receipt>>(emptyList())
    var names by mutableStateOf<Map<String, String>>(emptyMap())
    var results by mutableStateOf<List<Profile>>(emptyList())
    var incoming by mutableStateOf<CallRow?>(null)
    var call by mutableStateOf<CallSession?>(null)
    var error by mutableStateOf<String?>(null)
    var busy by mutableStateOf(false)
    var addingAccount by mutableStateOf(false)
    var foreground = true
    var pendingConv: String? = null

    private var inboxJob: Job? = null
    private var beatJob: Job? = null
    private var searchJob: Job? = null

    init {
        viewModelScope.launch {
            be.client.auth.sessionStatus.collect { if (it is SessionStatus.Authenticated) be.persist(it.session) }
        }
        viewModelScope.launch { boot() }
    }

    private fun fail(e: Throwable) { error = e.message?.take(160) ?: "error" }

    private suspend fun boot() {
        if (!be.configured) { screen = Screen.Auth; return }
        val saved = be.store.all()
        val acc = saved.firstOrNull { it.userId == be.store.activeId } ?: saved.firstOrNull()
        if (acc == null) { screen = Screen.Auth; return }
        try { be.activate(acc); enter() } catch (e: Exception) { fail(e); screen = Screen.Auth }
    }

    // ---------------- accounts ----------------
    fun submitAuth(username: String, password: String, display: String, signUp: Boolean) {
        if (busy) return
        busy = true; error = null
        viewModelScope.launch {
            try {
                if (signUp) be.signUp(username, password, display) else be.signIn(username, password)
                addingAccount = false
                enter()
            } catch (e: Exception) { fail(e) } finally { busy = false }
        }
    }

    fun switchTo(acc: Account) = viewModelScope.launch {
        try { stopLive(); be.activate(acc); enter() } catch (e: Exception) { fail(e) }
    }

    fun beginAddAccount() { addingAccount = true; error = null; screen = Screen.Auth }

    fun removeAccount(acc: Account) = viewModelScope.launch {
        try {
            val wasActive = acc.userId == be.meId
            if (wasActive) {
                stopLive()
                unregisterPush()
                be.signOutCurrent()
            }
            be.store.remove(acc.userId)
            accounts = be.store.all()
            if (wasActive) {
                val next = accounts.firstOrNull()
                if (next != null) { be.activate(next); enter() } else { me = null; convs = emptyList(); screen = Screen.Auth }
            }
        } catch (e: Exception) { fail(e) }
    }

    private suspend fun enter() {
        be.meId.takeIf { it.isNotBlank() } ?: return
        me = be.me(be.meId)
        accounts = be.store.all(); be.store.activeId = be.meId
        openConv = null; msgs = emptyList(); receipts = emptyList(); incoming = null
        convs = be.conversations()
        screen = Screen.List
        inboxJob?.cancel(); inboxJob = viewModelScope.launch { runCatching { be.runInbox(::onMsg, ::onCall, ::onReceipt) } }
        beatJob?.cancel(); beatJob = viewModelScope.launch { while (true) { if (foreground) runCatching { be.heartbeat() }; delay(30_000) } }
        registerPush()
        runCatching { be.recentCalls().firstOrNull() }.getOrNull()?.let { showIncoming(it) }
        pendingConv?.let { id -> convs.firstOrNull { it.id == id }?.let { openChat(it) }; pendingConv = null }
    }

    private fun stopLive() { inboxJob?.cancel(); beatJob?.cancel(); endCall() }

    private suspend fun registerPush() = runCatching {
        if (FirebaseApp.getApps(getApplication()).isNotEmpty()) be.registerDevice(FirebaseMessaging.getInstance().token.await())
    }
    private suspend fun unregisterPush() = runCatching {
        if (FirebaseApp.getApps(getApplication()).isNotEmpty()) be.unregisterDevice(FirebaseMessaging.getInstance().token.await())
    }

    // per-account settings
    fun notificationsOn() = me?.let { be.store.flag(it.id, "notif", true) } ?: true
    fun setNotifications(on: Boolean) { me?.let { be.store.setFlag(it.id, "notif", on) } }
    fun rename(name: String) = viewModelScope.launch {
        runCatching { be.setDisplayName(name); me = be.me(be.meId); accounts = be.store.all().map { if (it.userId == be.meId) it.copy(displayName = me!!.displayName) else it } }.onFailure(::fail)
    }

    // ---------------- conversations ----------------
    fun refreshConvs() = viewModelScope.launch { runCatching { convs = be.conversations() } }

    fun openChat(c: ConvRow) = viewModelScope.launch {
        try {
            openConv = c; msgs = be.messages(c.id); receipts = be.receipts(c.id); screen = Screen.Chat
            loadNames(); be.markRead(c.id); refreshConvs()
        } catch (e: Exception) { fail(e) }
    }

    fun closeChat() { openConv = null; screen = Screen.List; refreshConvs() }

    private suspend fun loadNames() {
        val missing = msgs.map { it.senderId }.distinct().filter { it !in names }
        if (missing.isNotEmpty()) runCatching { names = names + be.profiles(missing).associate { it.id to it.displayName } }
    }

    fun search(q: String) {
        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            delay(250)
            results = if (q.trim().length < 2) emptyList() else runCatching { be.search(q) }.getOrDefault(emptyList())
        }
    }

    fun startDirect(p: Profile) = viewModelScope.launch {
        try {
            val id = be.startDirect(p.id); convs = be.conversations()
            convs.firstOrNull { it.id == id }?.let { openChat(it) }
        } catch (e: Exception) { fail(e) }
    }

    fun createGroup(title: String, members: List<Profile>) = viewModelScope.launch {
        try {
            val id = be.createGroup(title.ifBlank { "Group" }, members.map { it.id }); convs = be.conversations()
            convs.firstOrNull { it.id == id }?.let { openChat(it) }
        } catch (e: Exception) { fail(e) }
    }

    // ---------------- messaging ----------------
    fun sendText(text: String, kind: String = "text") {
        val c = openConv ?: return
        if (text.isBlank()) return
        viewModelScope.launch { runCatching { addMsg(be.send(MsgInsert(c.id, kind, text.trim()))) }.onFailure(::fail) }
    }

    fun sendUri(uri: Uri) {
        val c = openConv ?: return
        viewModelScope.launch {
            try {
                val cr = getApplication<Application>().contentResolver
                val mime = cr.getType(uri).orEmpty()
                val name = cr.query(uri, null, null, null, null)?.use { cur ->
                    val i = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (cur.moveToFirst() && i >= 0) cur.getString(i) else null
                } ?: "file"
                val bytes = cr.openInputStream(uri)!!.use { it.readBytes() }
                require(bytes.size <= 50 * 1024 * 1024) { "Files up to 50 MB" }
                val kind = when { mime.startsWith("image/") -> "image"; mime.startsWith("video/") -> "video"; else -> "file" }
                val path = be.upload(bytes, name.substringAfterLast('.', ""))
                addMsg(be.send(MsgInsert(c.id, kind, null, path, name)))
            } catch (e: Exception) { fail(e) }
        }
    }

    fun sendVoice(f: File) {
        val c = openConv ?: return
        viewModelScope.launch {
            try {
                val path = be.upload(f.readBytes(), "m4a")
                addMsg(be.send(MsgInsert(c.id, "voice", null, path, "voice.m4a")))
            } catch (e: Exception) { fail(e) } finally { f.delete() }
        }
    }

    /** Opens a video/file in the system viewer through a fresh short-lived signed URL. */
    fun openExternal(ctx: android.content.Context, path: String) {
        viewModelScope.launch {
            runCatching {
                val i = android.content.Intent(android.content.Intent.ACTION_VIEW, Uri.parse(be.url(path)))
                    .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(i)
            }.onFailure(::fail)
        }
    }

    private suspend fun addMsg(m: Msg) {
        if (m.conversationId == openConv?.id && msgs.none { it.id == m.id }) msgs = msgs + m
        loadNames(); convs = runCatching { be.conversations() }.getOrDefault(convs)
    }

    // ---------------- realtime callbacks ----------------
    private fun onMsg(m: Msg) { viewModelScope.launch {
        val mine = m.senderId == be.meId
        if (openConv?.id == m.conversationId) {
            addMsg(m); if (!mine) runCatching { be.markRead(m.conversationId) }
        } else {
            if (!mine) runCatching { be.markDelivered(m.conversationId) }
            convs = runCatching { be.conversations() }.getOrDefault(convs)
        }
    } }

    private fun onReceipt() { viewModelScope.launch {
        openConv?.let { c -> runCatching { receipts = be.receipts(c.id) } }
    } }

    private fun onCall(c: CallRow) = showIncoming(c)

    private fun showIncoming(c: CallRow) {
        if (c.callerId == be.meId || c.endedAt != null || call != null || ageSeconds(c.createdAt) > 45) return
        incoming = c
        viewModelScope.launch { delay(45_000); if (incoming?.id == c.id) incoming = null }
    }

    // ---------------- calls ----------------
    fun startCall(video: Boolean) {
        val c = openConv ?: return
        viewModelScope.launch { try { join(be.startCall(c.id, video)) } catch (e: Exception) { fail(e) } }
    }

    fun acceptCall() { val c = incoming ?: return; incoming = null; viewModelScope.launch { join(c) } }
    fun declineCall() { incoming = null }

    private suspend fun join(row: CallRow) {
        val conv = convs.firstOrNull { it.id == row.conversationId }
        val s = CallSession(getApplication(), row.id, row.video, conv?.title.orEmpty(), conv?.isGroup == true, row.callerId == be.meId)
        call = s; screen = Screen.Call
        try { s.connect(viewModelScope, be.livekitToken(row.id)) { endCall() } }
        catch (e: Exception) { fail(e); endCall() }
    }

    fun endCall() {
        val s = call ?: return
        call = null
        s.disconnect()
        if (s.iAmCaller && !s.isGroup) viewModelScope.launch { runCatching { be.endCall(s.callId) } }
        screen = if (openConv != null) Screen.Chat else Screen.List
    }
}
