package com.redapp.app.push

import android.app.PendingIntent
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.redapp.app.MainActivity
import com.redapp.app.R
import com.redapp.app.RedApp

/**
 * Receives FCM data messages. Every message names the recipient account (`uid`), so with several
 * accounts on one device each notification is routed to, and filtered by, the right account.
 */
class PushService : FirebaseMessagingService() {
    override fun onMessageReceived(m: RemoteMessage) {
        val d = m.data
        val uid = d["uid"] ?: return
        val store = (application as RedApp).backend.store
        if (store.all().none { it.userId == uid }) return                 // account removed from this device
        if (!store.flag(uid, "notif", true)) return                       // muted for this account
        val isCall = d["call"] == "1"
        val open = PendingIntent.getActivity(
            this, uid.hashCode(),
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("uid", uid); putExtra("conv", d["conv"])
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val n = NotificationCompat.Builder(this, if (isCall) "call" else "messages")
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(d["title"] ?: "RedApp")
            .setContentText(d["body"])
            .setAutoCancel(true).setContentIntent(open)
            .setCategory(if (isCall) NotificationCompat.CATEGORY_CALL else NotificationCompat.CATEGORY_MESSAGE)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        runCatching { NotificationManagerCompat.from(this).notify((uid + d["conv"]).hashCode(), n) }
    }

    override fun onNewToken(token: String) {
        // The token is registered for the active account each time an account is activated (see AppVM.registerPush).
    }
}
