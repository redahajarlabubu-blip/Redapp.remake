package com.redapp.app

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.redapp.app.ui.*
import com.redapp.app.ui.Text

class MainActivity : ComponentActivity() {
    private val vm: AppVM by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handle(intent)
        setContent { RedAppTheme { Root(vm) } }
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); handle(intent) }
    override fun onStart() { super.onStart(); vm.foreground = true }
    override fun onStop() { super.onStop(); vm.foreground = false }

    /** Tapping a notification opens that conversation (only if that account is on this device). */
    private fun handle(i: Intent?) {
        val conv = i?.getStringExtra("conv") ?: return
        val uid = i.getStringExtra("uid")
        vm.pendingConv = conv
        val acc = vm.accounts.firstOrNull { it.userId == uid }
        if (acc != null && vm.me?.id != uid) vm.switchTo(acc)
        else vm.convs.firstOrNull { it.id == conv }?.let { vm.openChat(it); vm.pendingConv = null }
    }
}

@Composable
private fun Root(vm: AppVM) {
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) { if (Build.VERSION.SDK_INT >= 33) notif.launch(Manifest.permission.POST_NOTIFICATIONS) }

    BackHandler(enabled = vm.screen != Screen.List && vm.screen != Screen.Boot && vm.call == null) {
        when (vm.screen) {
            Screen.Chat -> vm.closeChat()
            Screen.Auth -> if (vm.addingAccount) { vm.addingAccount = false; vm.screen = Screen.Settings }
            else -> vm.screen = Screen.List
        }
    }

    Box(Modifier.fillMaxSize().background(Color.White)) {
        when (vm.screen) {
            Screen.Boot -> Box(Modifier.fillMaxSize(), Alignment.Center) { BrandWord(40.sp) }
            Screen.Auth -> AuthScreen(vm)
            Screen.List -> ListScreen(vm)
            Screen.Chat -> ChatScreen(vm)
            Screen.NewChat -> NewChatScreen(vm, group = false)
            Screen.NewGroup -> NewChatScreen(vm, group = true)
            Screen.Settings -> SettingsScreen(vm)
            Screen.Call -> CallScreen(vm)
        }
        vm.incoming?.let { IncomingCall(vm, it) }
    }
}

@Composable
private fun IncomingCall(vm: AppVM, c: com.redapp.app.data.CallRow) {
    val who = vm.convs.firstOrNull { it.id == c.conversationId }?.title.orEmpty()
    val accept = withCallPermissions(c.video) { vm.acceptCall() }
    AlertDialog(
        onDismissRequest = { vm.declineCall() },
        title = { Text(stringResource(if (c.video) R.string.incoming_video else R.string.incoming_call), fontSize = 20.sp) },
        text = { Text(who, fontSize = 18.sp) },
        confirmButton = { TextButton(accept) { Text(stringResource(R.string.accept), color = C.Live) } },
        dismissButton = { TextButton({ vm.declineCall() }) { Text(stringResource(R.string.decline), color = C.Bad) } },
    )
}
