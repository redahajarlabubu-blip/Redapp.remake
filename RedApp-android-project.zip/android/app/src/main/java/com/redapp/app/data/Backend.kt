package com.redapp.app.data

import android.content.Context
import com.redapp.app.BuildConfig
import io.github.jan.supabase.auth.Auth
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.auth.providers.builtin.Email
import io.github.jan.supabase.auth.user.UserSession
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.postgrest.query.Order
import io.github.jan.supabase.realtime.PostgresAction
import io.github.jan.supabase.realtime.Realtime
import io.github.jan.supabase.realtime.channel
import io.github.jan.supabase.realtime.decodeRecord
import io.github.jan.supabase.realtime.postgresChangeFlow
import io.github.jan.supabase.realtime.realtime
import io.github.jan.supabase.storage.Storage
import io.github.jan.supabase.storage.storage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.time.Duration.Companion.hours

class Backend(ctx: Context) {
    val store = AccountStore(ctx)
    val configured = BuildConfig.SUPABASE_URL.startsWith("https://") && BuildConfig.SUPABASE_ANON_KEY.isNotBlank()
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val http = OkHttpClient()
    private val urls = ConcurrentHashMap<String, String>()

    val client = createSupabaseClient(
        BuildConfig.SUPABASE_URL.ifBlank { "https://not-configured.invalid" },
        BuildConfig.SUPABASE_ANON_KEY.ifBlank { "not-configured" },
    ) {
        install(Auth) { autoLoadFromStorage = false; alwaysAutoRefresh = true }
        install(Postgrest)
        install(Realtime)
        install(Storage)
    }

    var meId: String = ""
        private set

    // ---- accounts / sessions -------------------------------------------------------------
    // No email or SMS verification: the username is mapped to a private placeholder email.
    // In Supabase: Authentication > Providers > Email > turn OFF "Confirm email".
    private fun email(username: String) = "${username.trim().lowercase()}@redapp.user"

    suspend fun signUp(username: String, password: String, display: String): Account {
        client.auth.signUpWith(Email) {
            email = email(username); this.password = password
            data = buildJsonObject {
                put("username", username.trim().lowercase())
                put("display_name", display.trim().ifBlank { username.trim() })
            }
        }
        return finishLogin()
    }

    suspend fun signIn(username: String, password: String): Account {
        client.auth.signInWith(Email) { email = email(username); this.password = password }
        return finishLogin()
    }

    private suspend fun finishLogin(): Account {
        val s = client.auth.currentSessionOrNull() ?: error("No session. Disable 'Confirm email' in Supabase.")
        val uid = s.user?.id ?: error("No user")
        meId = uid
        val p = me(uid)
        val acc = Account(uid, p.username, p.displayName, json.encodeToString(s))
        store.save(acc); store.activeId = uid
        urls.clear()
        return acc
    }

    /** Make [acc] the live session (used at launch and when switching accounts). */
    suspend fun activate(acc: Account) {
        client.auth.importSession(json.decodeFromString<UserSession>(acc.session))
        runCatching { client.auth.refreshCurrentSession() }
        meId = acc.userId
        urls.clear()
    }

    /** Keep stored tokens fresh when the SDK auto-refreshes them. */
    fun persist(session: UserSession) {
        val uid = session.user?.id ?: return
        store.all().firstOrNull { it.userId == uid }?.let { store.save(it.copy(session = json.encodeToString(session))) }
    }

    suspend fun signOutCurrent() { runCatching { client.auth.signOut() } }

    // ---- profiles / search -----------------------------------------------------------------
    suspend fun me(id: String): Profile =
        client.from("profiles").select { filter { eq("id", id) } }.decodeSingle()

    suspend fun profiles(ids: List<String>): List<Profile> =
        if (ids.isEmpty()) emptyList() else client.from("profiles").select { filter { isIn("id", ids) } }.decodeList()

    suspend fun search(q: String): List<Profile> {
        val safe = q.trim().lowercase().replace(Regex("[^a-z0-9_ ]"), "")
        return client.from("profiles").select {
            filter { or { ilike("username", "%$safe%"); ilike("display_name", "%$safe%") }; neq("id", meId) }
            limit(25)
        }.decodeList()
    }

    suspend fun setDisplayName(name: String) {
        client.from("profiles").update({ set("display_name", name.trim()) }) { filter { eq("id", meId) } }
    }

    suspend fun heartbeat() { client.postgrest.rpc("heartbeat") }

    // ---- conversations / messages ----------------------------------------------------------
    suspend fun conversations(): List<ConvRow> = client.postgrest.rpc("my_conversations").decodeList()

    suspend fun startDirect(other: String): String =
        client.postgrest.rpc("start_direct", buildJsonObject { put("other", other) }).decodeAs<String>()

    suspend fun createGroup(title: String, ids: List<String>): String =
        client.postgrest.rpc("create_group", buildJsonObject {
            put("title", title)
            put("member_ids", kotlinx.serialization.json.JsonArray(ids.map { kotlinx.serialization.json.JsonPrimitive(it) }))
        }).decodeAs<String>()

    suspend fun messages(conv: String): List<Msg> =
        client.from("messages").select {
            filter { eq("conversation_id", conv) }
            order("created_at", Order.ASCENDING)
            limit(500)
        }.decodeList()

    suspend fun send(m: MsgInsert): Msg = client.from("messages").insert(m) { select() }.decodeSingle()

    suspend fun receipts(conv: String): List<Receipt> =
        client.postgrest.rpc("chat_receipts", buildJsonObject { put("conv", conv) }).decodeList()

    suspend fun markRead(conv: String) { client.postgrest.rpc("mark_read", buildJsonObject { put("conv", conv) }) }
    suspend fun markDelivered(conv: String) { client.postgrest.rpc("mark_delivered", buildJsonObject { put("conv", conv) }) }

    // ---- media (private bucket + short-lived signed URLs) -------------------------------------
    suspend fun upload(bytes: ByteArray, ext: String): String {
        val path = "$meId/${UUID.randomUUID()}.${ext.ifBlank { "bin" }}"
        client.storage.from("media").upload(path, bytes)
        return path
    }

    suspend fun url(path: String): String =
        urls[path] ?: client.storage.from("media").createSignedUrl(path, 1.hours).also { urls[path] = it }

    // ---- calls ---------------------------------------------------------------------------------
    suspend fun startCall(conv: String, video: Boolean): CallRow =
        client.from("calls").insert(CallInsert(conv, video)) { select() }.decodeSingle()

    suspend fun endCall(id: String) {
        client.from("calls").update({ set("ended_at", java.time.Instant.now().toString()) }) { filter { eq("id", id) } }
    }

    suspend fun recentCalls(): List<CallRow> =
        client.from("calls").select {
            filter { filter("ended_at", io.github.jan.supabase.postgrest.query.filter.FilterOperator.IS, "null") }
            order("created_at", Order.DESCENDING); limit(5)
        }.decodeList<CallRow>().filter { it.callerId != meId && ageSeconds(it.createdAt) < 45 }

    /** LiveKit join token, minted by the `livekit-token` Edge Function after a membership check. */
    suspend fun livekitToken(callId: String): String = withContext(Dispatchers.IO) {
        val jwt = client.auth.currentAccessTokenOrNull() ?: error("Not signed in")
        val req = Request.Builder()
            .url("${BuildConfig.SUPABASE_URL}/functions/v1/livekit-token")
            .addHeader("Authorization", "Bearer $jwt").addHeader("apikey", BuildConfig.SUPABASE_ANON_KEY)
            .post("""{"call_id":"$callId"}""".toRequestBody("application/json".toMediaType())).build()
        http.newCall(req).execute().use { r ->
            val b = r.body?.string().orEmpty()
            if (!r.isSuccessful) error("Call token failed ($b)")
            json.parseToJsonElement(b).jsonObject["token"]!!.jsonPrimitive.content
        }
    }

    // ---- push -------------------------------------------------------------------------------------
    suspend fun registerDevice(token: String) { client.postgrest.rpc("register_device", buildJsonObject { put("tok", token) }) }
    suspend fun unregisterDevice(token: String) { client.postgrest.rpc("unregister_device", buildJsonObject { put("tok", token) }) }

    // ---- realtime inbox -------------------------------------------------------------------------------
    /** Streams new messages, new calls and receipt changes (RLS limits it to this user's conversations). */
    suspend fun runInbox(onMsg: (Msg) -> Unit, onCall: (CallRow) -> Unit, onReceipt: () -> Unit) = coroutineScope {
        val ch = client.channel("inbox-$meId-${System.nanoTime()}")
        val m = ch.postgresChangeFlow<PostgresAction.Insert>("public") { table = "messages" }
        val c = ch.postgresChangeFlow<PostgresAction.Insert>("public") { table = "calls" }
        val r = ch.postgresChangeFlow<PostgresAction>("public") { table = "receipts" }
        launch { m.collect { runCatching { onMsg(it.decodeRecord<Msg>()) } } }
        launch { c.collect { runCatching { onCall(it.decodeRecord<CallRow>()) } } }
        launch { r.collect { onReceipt() } }
        ch.subscribe(blockUntilSubscribed = true)
        try { awaitCancellation() } finally { withContext(NonCancellable) { runCatching { client.realtime.removeChannel(ch) } } }
    }
}
